<script setup lang="ts">
import {ref} from "vue";
import {Toast} from "vant";
import Index from "../pages/Index.vue";
import Team from "../pages/Team.vue";

const onClickLeft = () => alert('左')
// const onClickRight = () => alert('')

const active = ref("index");
const onChange = (index: unknown) => Toast(`标签 ${index}`);





</script>

<template>

  <van-nav-bar
      title="标题"
      left-text="返回"
      right-text="按钮"
      left-arrow
      @click-left="onClickLeft"
      @click-right="onClickRight"
  >

  <van-search  placeholder="请输入搜索关键词" />
    <template #right>
      <van-search v-model="value" placeholder="请输入搜索关键词" input-align="center" />
    </template>
  <van-back-top class="custom">返回顶部</van-back-top>

  </van-nav-bar>

  <div id="content">
    <router-view/>
    <template v-if="active === 'index'">
      <Index />
    </template>
    <template v-if="active === 'team'">
      <Team />
    </template>

  </div>

  <van-tabbar route @change="onChange">
    <van-tabbar-item to="/" icon="home-o" name="index">主页</van-tabbar-item>
    <van-tabbar-item to="/team" icon="search" name="team">队伍</van-tabbar-item>
    <van-tabbar-item to="/user" icon="friends-o" name="user">个人</van-tabbar-item>
  </van-tabbar>
</template>

<style scoped>

/**
回到顶部
 */
.custom {
  width: 80px;
  font-size: 14px;
  text-align: center;
}
</style>