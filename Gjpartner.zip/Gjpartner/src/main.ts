import { createApp } from 'vue'
import App from './App.vue'
import {Button, NavBar} from 'vant';
import { IndexBar, IndexAnchor } from 'vant';
import { BackTop } from 'vant';
import { Search } from 'vant';
// import * as VueRouter from 'vue-router';

// import routes from "./config/route";

// import Vant from 'vant';
// import 'vant/lib/index.css';
// import '../global.css'
const app = createApp(App);
// app.use(Vant);

app.use(Button);
app.use(NavBar);
app.mount('#app')

app.use(IndexBar);
app.use(IndexAnchor);

app.use(BackTop);

app.use(Search);


// const router = VueRouter.createRouter({
//     // 内部提供了 history 模式的实现。为了简单起见，我们在这里使用 hash 模式。
//     history: VueRouter.createWebHistory(),
//     routes, // `routes: routes` 的缩写
// })
// app.use(router);