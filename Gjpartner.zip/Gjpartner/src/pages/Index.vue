<script >

export default {
  name: "Index.vue"
}

</script>

<template>

</template>

<style scoped>

</style>