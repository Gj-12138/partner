<script setup lang="ts">
import BasicLayout from "./layout/BasicLayout.vue"

</script>

<template>
<BasicLayout/>

</template>

<style scoped>

</style>
