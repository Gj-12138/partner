package com.gj.partner.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gj.partner.model.domain.UserTeam;
import com.gj.partner.service.UserTeamService;
import com.gj.partner.mapper.UserTeamMapper;
import org.springframework.stereotype.Service;

/**
* @author 14908
* @description 针对表【user_team(用户队伍关系)】的数据库操作Service实现
* @createDate 2024-07-29 17:23:07
*/
@Service
public class UserTeamServiceImpl extends ServiceImpl<UserTeamMapper, UserTeam>
    implements UserTeamService{

}




