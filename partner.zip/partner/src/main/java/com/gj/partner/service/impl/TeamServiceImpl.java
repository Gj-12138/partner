package com.gj.partner.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gj.partner.model.domain.Team;
import com.gj.partner.service.TeamService;
import com.gj.partner.mapper.TeamMapper;
import org.springframework.stereotype.Service;

/**
* @author 14908
* @description 针对表【team(队伍)】的数据库操作Service实现
* @createDate 2024-07-29 17:22:24
*/
@Service
public class TeamServiceImpl extends ServiceImpl<TeamMapper, Team>
    implements TeamService{

}




