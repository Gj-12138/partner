package com.gj.partner.mapper;

import com.gj.partner.model.domain.UserTeam;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 14908
* @description 针对表【user_team(用户队伍关系)】的数据库操作Mapper
* @createDate 2024-07-29 17:23:07
* @Entity generator.domain.UserTeam
*/
public interface UserTeamMapper extends BaseMapper<UserTeam> {

}




