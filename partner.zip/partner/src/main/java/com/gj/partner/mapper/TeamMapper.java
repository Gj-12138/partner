package com.gj.partner.mapper;

import com.gj.partner.model.domain.Team;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 14908
* @description 针对表【team(队伍)】的数据库操作Mapper
* @createDate 2024-07-29 17:22:24
* @Entity generator.domain.Team
*/
public interface TeamMapper extends BaseMapper<Team> {

}




