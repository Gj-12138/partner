package com.gj.partner.mapper;

import com.gj.partner.model.domain.Tag;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 14908
* @description 针对表【tag(标签)】的数据库操作Mapper
* @createDate 2024-07-29 17:20:57
* @Entity generator.domain.Tag
*/
public interface TagMapper extends BaseMapper<Tag> {

}




