package com.gj.partner.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gj.partner.model.domain.Tag;
import com.gj.partner.service.TagService;
import com.gj.partner.mapper.TagMapper;
import org.springframework.stereotype.Service;

/**
* @author 14908
* @description 针对表【tag(标签)】的数据库操作Service实现
* @createDate 2024-07-29 17:20:57
*/
@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag>
    implements TagService{

}




